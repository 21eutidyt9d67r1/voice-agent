# pylint: disable=line-too-long,useless-suppression
# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------
"""Customize generated code here.

Follow our quickstart for examples: https://aka.ms/azsdk/python/dpcodegen/python/customize
"""

from functools import wraps
import inspect
from typing import Any, Callable, List
from ..models._patch import _FOUNDRY_FEATURES_HEADER_NAME, _BETA_OPERATION_FEATURE_HEADERS, _has_header_case_insensitive
from .._realtime import (
    BetaRealtime,
    BetaRealtimeConnection,
    BetaRealtimeConnectionManager,
    ClientEvent,
    ConversationItem,
    ServerEvent,
)
from .._live import BetaLive, BetaLiveConnection, BetaLiveConnectionManager, LiveClientEvent, LiveServerEvent
from ._patch_agents import AgentsOperations, BetaAgentsOperations
from ._patch_agent_insights import BetaAgentInsightMonitorsOperations
from ._patch_datasets import DatasetsOperations
from ._patch_evaluators import EvaluatorsOperations
from ._patch_evaluation_rules import EvaluationRulesOperations
from ._patch_telemetry import TelemetryOperations
from ._patch_connections import ConnectionsOperations
from ._patch_memories import BetaMemoryStoresOperations
from ._patch_models import BetaModelsOperations
from ._operations import (
    BetaEvaluationTaxonomiesOperations,
    BetaInsightsOperations,
    BetaOperations as GeneratedBetaOperations,
    BetaRedTeamsOperations,
    BetaRoutinesOperations,
    BetaSchedulesOperations,
    BetaSkillsOperations,
    BetaVoiceAgentsConversationsOperations,
    BetaVoiceAgentsLiveConversationsOperations,
    BetaVoiceAgentsOperations as GeneratedBetaVoiceAgentsOperations,
    BetaVoiceAgentsTelephonyOperations,
)


def _method_accepts_keyword_headers(method: Callable[..., Any]) -> bool:
    try:
        signature = inspect.signature(method)
    except (TypeError, ValueError):
        return False

    for parameter in signature.parameters.values():
        if parameter.name == "headers":
            return True
        if parameter.kind == inspect.Parameter.VAR_KEYWORD:
            return True

    return False


class _OperationMethodHeaderProxy:
    """Proxy that injects the Foundry-Features header into public operation method calls."""

    def __init__(self, operation: Any, foundry_features_value: str):
        """Wrap an operation and its nested operation groups with the same header value.

        For example, ``.beta.voice_agents`` stores ``conversations`` and ``telephony`` as nested
        operation groups. Wrapping them with the parent proxy ensures every call under
        ``.beta.voice_agents.conversations`` and ``.beta.voice_agents.telephony`` receives the
        ``Foundry-Features: VoiceAgents=V1Preview`` header.
        """
        object.__setattr__(self, "_operation", operation)
        object.__setattr__(self, "_foundry_features_value", foundry_features_value)
        for name, attribute in vars(operation).items():
            # Generated operation groups share these fields; ordinary public attributes do not.
            if (
                not name.startswith("_")
                and not isinstance(attribute, _OperationMethodHeaderProxy)
                and hasattr(attribute, "_client")
                and hasattr(attribute, "_config")
            ):
                setattr(operation, name, _OperationMethodHeaderProxy(attribute, foundry_features_value))

    def __getattr__(self, name: str) -> Any:
        attribute = getattr(self._operation, name)

        if name.startswith("_"):
            return attribute
        if not callable(attribute):
            if isinstance(attribute, _OperationMethodHeaderProxy):
                return attribute
            # Also wrap an operation group that was assigned after this proxy was initialized.
            if hasattr(attribute, "_client") and hasattr(attribute, "_config"):
                return _OperationMethodHeaderProxy(attribute, self._foundry_features_value)
            return attribute
        if not _method_accepts_keyword_headers(attribute):
            return attribute

        @wraps(attribute)
        def _wrapped(*args: Any, **kwargs: Any) -> Any:
            headers = kwargs.get("headers")
            if headers is None:
                kwargs["headers"] = {_FOUNDRY_FEATURES_HEADER_NAME: self._foundry_features_value}
            elif not _has_header_case_insensitive(headers, _FOUNDRY_FEATURES_HEADER_NAME):
                try:
                    headers[_FOUNDRY_FEATURES_HEADER_NAME] = self._foundry_features_value
                except Exception:  # pylint: disable=broad-except
                    # Fall back to replacing invalid/immutable header containers.
                    kwargs["headers"] = {
                        _FOUNDRY_FEATURES_HEADER_NAME: self._foundry_features_value,
                    }

            return attribute(*args, **kwargs)

        return _wrapped

    def __dir__(self) -> list:
        return dir(self._operation)

    def __setattr__(self, name: str, value: Any) -> None:
        setattr(self._operation, name, value)


class BetaVoiceAgentsOperations(GeneratedBetaVoiceAgentsOperations):
    """
    .. warning::
        **DO NOT** instantiate this class directly.

        Instead, you should access the following operations through
        :class:`~azure.ai.projects.AIProjectClient`'s :attr:`beta` attribute's
        :attr:`~azure.ai.projects.operations.BetaOperations.voice_agents` attribute.
    """

    conversations: BetaVoiceAgentsConversationsOperations
    """:class:`~azure.ai.projects.operations.BetaVoiceAgentsConversationsOperations` operations"""
    telephony: BetaVoiceAgentsTelephonyOperations
    """:class:`~azure.ai.projects.operations.BetaVoiceAgentsTelephonyOperations` operations"""
    realtime: BetaRealtime
    """:class:`~azure.ai.projects.operations.BetaRealtime` operations"""
    live: BetaLive
    """:class:`~azure.ai.projects.operations.BetaLive` operations"""
    live_conversations: BetaVoiceAgentsLiveConversationsOperations
    """:class:`~azure.ai.projects.operations.BetaVoiceAgentsLiveConversationsOperations` operations"""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        # The generator does not emit realtime operations at all, since azure-core's HTTP
        # pipeline has no way to keep a WebSocket upgrade's resulting socket alive. Add our
        # hand-written client, which manages a real, long-lived connection, in its place.
        self.realtime = BetaRealtime(self)
        self.live = BetaLive(self)


class BetaOperations(GeneratedBetaOperations):
    """
    .. warning::
        **DO NOT** instantiate this class directly.

        Instead, you should access the following operations through
        :class:`~azure.ai.projects.AIProjectClient`'s
        :attr:`beta` attribute.
    """

    agents: BetaAgentsOperations
    """:class:`~azure.ai.projects.operations.BetaAgentsOperations` operations"""
    agent_insight_monitors: BetaAgentInsightMonitorsOperations
    """:class:`~azure.ai.projects.operations.BetaAgentInsightMonitorsOperations` operations"""
    evaluation_taxonomies: BetaEvaluationTaxonomiesOperations
    """:class:`~azure.ai.projects.operations.BetaEvaluationTaxonomiesOperations` operations"""
    insights: BetaInsightsOperations
    """:class:`~azure.ai.projects.operations.BetaInsightsOperations` operations"""
    memory_stores: BetaMemoryStoresOperations
    """:class:`~azure.ai.projects.operations.BetaMemoryStoresOperations` operations"""
    models: BetaModelsOperations
    """:class:`~azure.ai.projects.operations.BetaModelsOperations` operations"""
    red_teams: BetaRedTeamsOperations
    """:class:`~azure.ai.projects.operations.BetaRedTeamsOperations` operations"""
    routines: BetaRoutinesOperations
    """:class:`~azure.ai.projects.operations.BetaRoutinesOperations` operations"""
    schedules: BetaSchedulesOperations
    """:class:`~azure.ai.projects.operations.BetaSchedulesOperations` operations"""
    skills: BetaSkillsOperations
    """:class:`~azure.ai.projects.operations.BetaSkillsOperations` operations"""
    voice_agents: BetaVoiceAgentsOperations
    """:class:`~azure.ai.projects.operations.BetaVoiceAgentsOperations` operations"""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        # Replace with patched beta agents operations
        self.agents = BetaAgentsOperations(self._client, self._config, self._serialize, self._deserialize)
        # Replace with patched class that includes begin_update_memories
        self.memory_stores = BetaMemoryStoresOperations(self._client, self._config, self._serialize, self._deserialize)
        # Replace with patched class that includes create (3-step upload helper)
        self.models = BetaModelsOperations(self._client, self._config, self._serialize, self._deserialize)
        # Replace with patched class that returns AgentInsightRunLROPoller
        self.agent_insight_monitors = BetaAgentInsightMonitorsOperations(
            self._client, self._config, self._serialize, self._deserialize
        )
        # Replace with patched class that wires up the hand-written realtime client
        self.voice_agents = BetaVoiceAgentsOperations(self._client, self._config, self._serialize, self._deserialize)

        for property_name, foundry_features_value in _BETA_OPERATION_FEATURE_HEADERS.items():
            setattr(
                self,
                property_name,
                _OperationMethodHeaderProxy(getattr(self, property_name), foundry_features_value),
            )


__all__: List[str] = [
    "AgentsOperations",
    "BetaAgentInsightMonitorsOperations",
    "BetaAgentsOperations",
    "BetaEvaluationTaxonomiesOperations",
    "BetaInsightsOperations",
    "BetaMemoryStoresOperations",
    "BetaModelsOperations",
    "BetaOperations",
    "BetaRedTeamsOperations",
    "BetaRoutinesOperations",
    "BetaSchedulesOperations",
    "BetaSkillsOperations",
    "BetaVoiceAgentsConversationsOperations",
    "BetaVoiceAgentsLiveConversationsOperations",
    "BetaVoiceAgentsOperations",
    "BetaVoiceAgentsTelephonyOperations",
    "ClientEvent",
    "ConnectionsOperations",
    "ConversationItem",
    "DatasetsOperations",
    "EvaluatorsOperations",
    "EvaluationRulesOperations",
    "BetaRealtime",
    "BetaRealtimeConnection",
    "BetaRealtimeConnectionManager",
    "BetaLive",
    "BetaLiveConnection",
    "BetaLiveConnectionManager",
    "LiveClientEvent",
    "LiveServerEvent",
    "ServerEvent",
    "TelemetryOperations",
]  # Add all objects you want publicly available to users at this package level


def patch_sdk():
    """Do not remove from this file.

    `patch_sdk` is a last resort escape hatch that allows you to do customizations
    you can't accomplish using the techniques described in
    https://aka.ms/azsdk/python/dpcodegen/python/customize
    """
